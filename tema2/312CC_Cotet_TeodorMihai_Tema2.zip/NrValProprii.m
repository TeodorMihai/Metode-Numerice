function numvp = NrValProprii(d, s, val_lambda)

	%Intrari:
	% d = diagonala princiapal a matricei tridiagonale simterice
	% s = supradiagonala matricei tridiagonale simetrice
	% val_lambda = valoarea pentru care se calculeaza numarul de radacini mai mic decat ea
	%Iesiri:
	% numvp = numarul de valori proprii ale matricei mai mici decat val_lambda

	D = diag(d, 0) + diag(s, 1) + diag(s, - 1); %construiesc matricea, doar pentru debug
	n = columns(D); % dimesniunea matricei

	P = ValoriPolinoame(d, s, val_lambda); %sirul de polinoame

	numvp = 0; %initial avem zero

	for i = 1 : n

		if( P(i + 1) == 0 ) 
			numvp = numvp + 1;
			P(i + 1) = -P(i); % ii atribuim semnul opus polinomului precedent
			continue;
		end
		
		val =  P(i) * P(i + 1);
		
		
		if(val < 0) %asta se traduce ca varia de semn + cu - sau viceversa
			numvp = numvp + 1;
		end

	end


end